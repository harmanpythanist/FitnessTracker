using System;
using System.Windows.Forms;
using project.Forms;   // ✅ MOVE HERE
using project.Services;

namespace project;

static class Program
{
    /// <summary>
    ///  The main entry point for the application.
    /// </summary>
    [STAThread]
    static void Main()
    {
        // To customize application configuration such as set high DPI settings or default font,
        // see https://aka.ms/applicationconfiguration.
        UserStore.Load();
        MessageBox.Show("Started");
        ApplicationConfiguration.Initialize();
        

        Application.Run(new LoginForm());
    }    
}