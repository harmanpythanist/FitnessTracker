using System.Drawing;
using System.Windows.Forms;

namespace project.UI
{
    public static class Theme
    {
        // Colors
        public static Color Background = Color.FromArgb(18, 18, 24);
        public static Color Surface = Color.FromArgb(28, 28, 36);
        public static Color Card = Color.FromArgb(34, 34, 44);

        public static Color Accent = Color.FromArgb(90, 140, 255);
        public static Color Success = Color.FromArgb(80, 200, 120);
        public static Color Danger = Color.FromArgb(255, 90, 100);
        public static Color Warning = Color.FromArgb(255, 170, 60);
        public static Color Purple = Color.FromArgb(170, 120, 255);

        public static Color TextPrimary = Color.White;
        public static Color TextSec = Color.FromArgb(180, 180, 200);

        // Fonts
        public static Font FontTitle = new Font("Segoe UI", 18f, FontStyle.Bold);
        public static Font FontHeading = new Font("Segoe UI", 12f, FontStyle.Bold);
        public static Font FontBody = new Font("Segoe UI", 10f, FontStyle.Regular);
        public static Font FontSmall = new Font("Segoe UI", 9f, FontStyle.Regular);

        // Styled Label
        public static Label StyledLabel(string text, int x, int y, Font font, Color color)
        {
            return new Label
            {
                Text = text,
                Left = x,
                Top = y,
                AutoSize = true,
                Font = font,
                ForeColor = color,
                BackColor = Color.Transparent
            };
        }

        // Styled TextBox
        public static TextBox StyledTextBox()
        {
            return new TextBox
            {
                Width = 200,
                Height = 30,
                Font = FontBody,
                BackColor = Color.FromArgb(40, 40, 50),
                ForeColor = TextPrimary,
                BorderStyle = BorderStyle.FixedSingle
            };
        }

        // Styled Button
        public static Button StyledButton(string text)
        {
            var btn = new Button
            {
                Text = text,
                Width = 200,
                Height = 40,
                Font = FontBody,
                BackColor = Accent,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };

            btn.FlatAppearance.BorderSize = 0;

            btn.MouseEnter += (s, e) =>
            {
                btn.BackColor = Color.FromArgb(110, 160, 255);
            };

            btn.MouseLeave += (s, e) =>
            {
                btn.BackColor = Accent;
            };

            return btn;
        }
    }
}