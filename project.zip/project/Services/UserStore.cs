using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using project.Models;

namespace project.Services
{
    /// <summary>
    /// Handles user storage, authentication, and persistence (JSON).
    /// </summary>
    public static class UserStore
    {
        private static readonly string FilePath = "users.json";

        // All users (username → UserAccount)
        public static Dictionary<string, UserAccount> Users { get; private set; }

        // Currently logged-in user
        public static UserAccount CurrentUser { get; private set; }

        // ── Load Data ──
        public static void Load()
        {
            try
            {
                if (!File.Exists(FilePath))
                {
                    Users = new Dictionary<string, UserAccount>();
                    return;
                }

                string json = File.ReadAllText(FilePath);

                Users = JsonSerializer.Deserialize<Dictionary<string, UserAccount>>(json)
                        ?? new Dictionary<string, UserAccount>();
            }
            catch
            {
                // If file is corrupted → reset safely
                Users = new Dictionary<string, UserAccount>();
            }
        }

        // ── Save Data ──
        public static void Save()
        {
            try
            {
                var options = new JsonSerializerOptions
                {
                    WriteIndented = true
                };

                string json = JsonSerializer.Serialize(Users, options);
                File.WriteAllText(FilePath, json);
            }
            catch
            {
                // Optional: log error
            }
        }

        // ── Register User ──
        // ── Register User ──
        public static bool Register(string username, string hash, string name, string phone, out string error)
        {
            error = "";

            if (Users.ContainsKey(username))
            {
                error = "Username already exists.";
                return false;
            }

            var user = new UserAccount(username, hash);
            user.Name = name;
            user.Phone = phone;
            Users.Add(username, user);

            Save();
            return true;
        }

        // ── Login User ──
        public static bool Login(string username, string passwordHash, out string error)
        {
            error = "";

            if (!Users.ContainsKey(username))
            {
                error = "User not found.";
                return false;
            }

            var user = Users[username];

            // Check if locked
            if (user.IsLocked)
            {
                error = "Account is locked due to multiple failed attempts.";
                return false;
            }

            // Check password
            if (user.PasswordHash != passwordHash)
            {
                user.FailedAttempts++;

                if (user.FailedAttempts >= 3)
                {
                    user.IsLocked = true;
                    error = "Account locked after 3 failed attempts.";
                }
                else
                {
                    error = $"Incorrect password. Attempts left: {3 - user.FailedAttempts}";
                }

                Save();
                return false;
            }

            // Success login
            user.FailedAttempts = 0;
            CurrentUser = user;

            Save();
            return true;
        }

        // ── Logout ──
        public static void Logout()
        {
            CurrentUser = null;
        }
    }
}