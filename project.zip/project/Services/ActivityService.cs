using System;
using project.Models;

namespace project.Services
{
    public static class ActivityService
    {
        public static ActivityEntry CreateActivity(string name, double m1, double m2, double m3)
        {
            double calories = CalculateCalories(name, m1, m2, m3);

            GetMetricLabels(name, out string l1, out string l2, out string l3);

            return new ActivityEntry(
                name,
                l1, m1,
                l2, m2,
                l3, m3,
                calories
            );
        }

        public static double CalculateCalories(string name, double m1, double m2, double m3)
        {
            switch (name)
            {
                case "Walking":
                    return m2 * 50 + m3 * 2;

                case "Running":
                    return m2 * 80 + m3 * 5;

                case "Cycling":
                    return m2 * 60 + m3 * 4;

                case "Swimming":
                    return m2 * 70 + m3 * 6;

                case "Pushups":
                    return m1 * 0.5 + m3 * 2;

                case "Jump Rope":
                    return m3 * 10 + m1 * 0.2;

                default:
                    return 0;
            }
        }

        public static void GetMetricLabels(string name, out string l1, out string l2, out string l3)
        {
            l1 = "Metric1";
            l2 = "Metric2";
            l3 = "Metric3";

            switch (name)
            {
                case "Walking":
                case "Running":
                    l1 = "Steps";
                    l2 = "Distance (km)";
                    l3 = "Time (min)";
                    break;

                case "Cycling":
                    l1 = "Distance (km)";
                    l2 = "Speed (km/h)";
                    l3 = "Time (min)";
                    break;

                case "Swimming":
                    l1 = "Laps";
                    l2 = "Distance (m)";
                    l3 = "Time (min)";
                    break;

                case "Pushups":
                    l1 = "Reps";
                    l2 = "Sets";
                    l3 = "Time (min)";
                    break;

                case "Jump Rope":
                    l1 = "Jumps";
                    l2 = "Speed";
                    l3 = "Time (min)";
                    break;
            }
        }
    }
}