﻿using System.Windows.Forms;  // important!

namespace project
{
    public partial class Form1 : Form  // <-- must inherit from Form
    {
        public Form1()
        {
            InitializeComponent();
        }
    }
}