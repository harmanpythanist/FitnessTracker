using System;
using System.Drawing;
using System.Windows.Forms;
using project.Services;
using project.Security;
using project.UI;

namespace project.Forms
{
    public class LoginForm : Form
    {
        TextBox tbUsername, tbPassword;
        Label lblError;

        public LoginForm()
        {
            Text = "FitTrack — Login";
            Size = new Size(500, 500); // ✅ slightly larger window
            MinimumSize = new Size(500, 500);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Theme.Background;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;

            BuildUI();
        }

        void BuildUI()
        {
            // Title
            var lblTitle = new Label
            {
                Text = "Welcome to FitTrack",
                Left = 40,
                Top = 30,
                AutoSize = true,
                Font = Theme.FontTitle,
                ForeColor = Theme.TextPrimary
            };
            Controls.Add(lblTitle);

            // Card panel for login inputs
            var card = new Panel
            {
                Left = 50,
                Top = 90,
                Width = 380,
                Height = 260,
                BackColor = Theme.Surface,
                Padding = new Padding(20)
            };
            Controls.Add(card);

            // Username
            card.Controls.Add(Theme.StyledLabel("Username", 0, 0, Theme.FontSmall, Theme.TextSec));
            tbUsername = Theme.StyledTextBox();
            tbUsername.Left = 0;
            tbUsername.Top = 30;
            tbUsername.Width = card.Width - 40; // fit inside card
            card.Controls.Add(tbUsername);

            // Password
            card.Controls.Add(Theme.StyledLabel("Password", 0, 70, Theme.FontSmall, Theme.TextSec));
            tbPassword = Theme.StyledTextBox();
            tbPassword.Left = 0;
            tbPassword.Top = 100;
            tbPassword.Width = card.Width - 40;
            tbPassword.UseSystemPasswordChar = true;
            card.Controls.Add(tbPassword);

            // Error label
            lblError = new Label
            {
                Left = 0,
                Top = 140,
                Width = card.Width - 40,
                Height = 25,
                ForeColor = Theme.Danger,
                Font = Theme.FontSmall,
                TextAlign = ContentAlignment.MiddleLeft
            };
            card.Controls.Add(lblError);

            // Login button
            var btnLogin = Theme.StyledButton("LOGIN");
            btnLogin.Left = 0;
            btnLogin.Top = 180;
            btnLogin.Width = card.Width - 40;
            card.Controls.Add(btnLogin);

            btnLogin.Click += (s, e) =>
            {
                lblError.Text = "";

                string username = tbUsername.Text.Trim();
                string password = tbPassword.Text;

                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                {
                    lblError.Text = "Please enter both username and password.";
                    return;
                }

                string hash = SecurityHelper.HashPassword(password);

                if (!UserStore.Login(username, hash, out string error))
                {
                    lblError.Text = error;
                    return;
                }

                var dash = new DashboardForm();
                dash.Show();
                this.Hide();
            };

            // Create account button
            var btnRegister = Theme.StyledButton("Create Account");
            btnRegister.Left = 50;
            btnRegister.Top = card.Bottom + 20; // place below card with padding
            btnRegister.Width = 380;
            Controls.Add(btnRegister);

            btnRegister.Click += (s, e) =>
            {
                var reg = new RegisterForm();
                reg.ShowDialog();
            };
        }
    }
}