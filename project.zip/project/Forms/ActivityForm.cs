using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using project.Models;
using project.Services;
using project.UI;

namespace project.Forms
{
    public class ActivityForm : Form
    {
        ComboBox cbActivity;
        TextBox tb1, tb2, tb3;
        Label lbl1, lbl2, lbl3, lblError;

        // Each activity maps to 3 metric labels and their units/hints
        static readonly Dictionary<string, (string L1, string L2, string L3)> MetricLabels =
            new Dictionary<string, (string, string, string)>
            {
                { "Walking",   ("Steps taken",           "Distance (km)",      "Time taken (min)") },
                { "Running",   ("Distance (km)",          "Average speed (km/h)","Time taken (min)") },
                { "Cycling",   ("Distance (km)",          "Average speed (km/h)","Time taken (min)") },
                { "Swimming",  ("Number of laps",         "Time taken (min)",   "Avg heart rate (bpm)") },
                { "Pushups",   ("Number of reps",         "Number of sets",     "Time taken (min)") },
                { "Jump Rope", ("Number of jumps",        "Time taken (min)",   "Avg heart rate (bpm)") },
            };

        public ActivityForm()
        {
            Text = "Add Activity";
            Size = new Size(420, 500);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Background;
            FormBorderStyle = FormBorderStyle.FixedDialog;

            BuildUI();
        }

        void BuildUI()
        {
            var card = new Panel
            {
                Left = 30,
                Top = 30,
                Width = 340,
                Height = 400,
                BackColor = Theme.Surface
            };
            Controls.Add(card);

            // ── Heading ──────────────────────────────────────────────────
            card.Controls.Add(Theme.StyledLabel(
                "Select Activity", 20, 20, Theme.FontHeading, Theme.TextPrimary));

            // ── Activity dropdown ─────────────────────────────────────────
            cbActivity = new ComboBox
            {
                Left = 20,
                Top = 50,
                Width = 280,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cbActivity.Items.AddRange(new string[]
            {
                "Walking", "Running", "Cycling",
                "Swimming", "Pushups", "Jump Rope"
            });
            cbActivity.SelectedIndexChanged += OnActivityChanged;
            card.Controls.Add(cbActivity);

            // ── Metric 1 ──────────────────────────────────────────────────
            lbl1 = Theme.StyledLabel("Metric 1", 20, 90, Theme.FontBody, Theme.TextSec);
            tb1 = Theme.StyledTextBox(); tb1.Left = 20; tb1.Top = 110; tb1.Width = 280;
            card.Controls.Add(lbl1);
            card.Controls.Add(tb1);

            // ── Metric 2 ──────────────────────────────────────────────────
            lbl2 = Theme.StyledLabel("Metric 2", 20, 150, Theme.FontBody, Theme.TextSec);
            tb2 = Theme.StyledTextBox(); tb2.Left = 20; tb2.Top = 170; tb2.Width = 280;
            card.Controls.Add(lbl2);
            card.Controls.Add(tb2);

            // ── Metric 3 ──────────────────────────────────────────────────
            lbl3 = Theme.StyledLabel("Metric 3", 20, 210, Theme.FontBody, Theme.TextSec);
            tb3 = Theme.StyledTextBox(); tb3.Left = 20; tb3.Top = 230; tb3.Width = 280;
            card.Controls.Add(lbl3);
            card.Controls.Add(tb3);

            // ── Error label ───────────────────────────────────────────────
            lblError = new Label
            {
                Left = 20,
                Top = 270,
                Width = 280,
                ForeColor = Theme.Danger
            };
            card.Controls.Add(lblError);

            // ── Submit button ─────────────────────────────────────────────
            var btn = Theme.StyledButton("Add Activity");
            btn.Left = 20; btn.Top = 300; btn.Width = 280;
            card.Controls.Add(btn);

            btn.Click += OnAddActivity;
        }

        // Dynamically update metric labels whenever a different activity is chosen
        void OnActivityChanged(object sender, EventArgs e)
        {
            if (cbActivity.SelectedItem == null) return;

            string activity = cbActivity.SelectedItem.ToString();
            if (MetricLabels.TryGetValue(activity, out var labels))
            {
                lbl1.Text = labels.L1;
                lbl2.Text = labels.L2;
                lbl3.Text = labels.L3;
            }

            // Clear previous inputs and errors when activity changes
            tb1.Text = tb2.Text = tb3.Text = "";
            lblError.Text = "";
        }

        void OnAddActivity(object sender, EventArgs e)
        {
            lblError.Text = "";

            if (cbActivity.SelectedItem == null)
            {
                lblError.Text = "Please select an activity.";
                return;
            }

            if (!double.TryParse(tb1.Text, out double m1) || m1 < 0 ||
                !double.TryParse(tb2.Text, out double m2) || m2 < 0 ||
                !double.TryParse(tb3.Text, out double m3) || m3 < 0)
            {
                lblError.Text = "Please enter valid positive numbers for all metrics.";
                return;
            }

            string name = cbActivity.SelectedItem.ToString();
            var metrics = MetricLabels[name];
            double calories = CalculateCalories(name, m1, m2, m3);

            var act = new ActivityEntry(
                name,
                metrics.L1, m1,
                metrics.L2, m2,
                metrics.L3, m3,
                calories
            );

            UserStore.CurrentUser.AddActivity(act);
            UserStore.Save();
            this.Close();
        }

        // ── Calorie formulas ──────────────────────────────────────────────
        //
        //  Walking   : MET ≈ 3.5 | Calories = MET × weight(assumed 70 kg) × time(h)
        //              steps and distance used to derive a richer estimate
        //  Running   : MET ≈ 9.8 | Calories = distance(km) × weight × 1.036
        //              speed used to pick a more accurate MET band
        //  Cycling   : MET ≈ 8.0 | Calories = MET × 70 × (time / 60)
        //  Swimming  : Calories = laps × 15  +  heartRateBonus
        //              (each lap ~15 kcal; elevated HR adds extra burn)
        //  Pushups   : Calories = reps × sets × 0.36  +  time × 3
        //              (~0.36 kcal per push-up; time accounts for rest/rest burn)
        //  Jump Rope : MET ≈ 12.3 | Calories = MET × 70 × (time / 60)
        //              jump count cross-checks the time estimate
        //
        double CalculateCalories(string name, double m1, double m2, double m3)
        {
            const double weight = 70.0; // assumed average body weight in kg

            switch (name)
            {
                case "Walking":
                    {
                        // m1 = steps, m2 = distance (km), m3 = time (min)
                        double met = 3.5;
                        double timeHrs = m3 / 60.0;
                        double base_cal = met * weight * timeHrs;
                        // bonus: each km walked burns roughly 60 kcal
                        double dist_cal = m2 * 60.0;
                        // average of both estimates for robustness
                        return Math.Round((base_cal + dist_cal) / 2.0, 1);
                    }

                case "Running":
                    {
                        // m1 = distance (km), m2 = avg speed (km/h), m3 = time (min)
                        // Speed-adjusted MET: slow jog ~8, fast run ~12
                        double met = m2 < 8 ? 8.0 : m2 < 12 ? 10.0 : 12.5;
                        double timeHrs = m3 / 60.0;
                        double base_cal = met * weight * timeHrs;
                        // Distance-based formula: ~1.036 kcal per kg per km
                        double dist_cal = m1 * weight * 1.036 / weight * weight / 70.0 * 70.0;
                        // dist_cal simplifies to m1 * 1.036 * weight / 70
                        dist_cal = m1 * 1.036 * weight / 70.0;
                        return Math.Round((base_cal + dist_cal) / 2.0, 1);
                    }

                case "Cycling":
                    {
                        // m1 = distance (km), m2 = avg speed (km/h), m3 = time (min)
                        double met = m2 < 16 ? 6.0 : m2 < 20 ? 8.0 : 10.0;
                        double timeHrs = m3 / 60.0;
                        double base_cal = met * weight * timeHrs;
                        // Distance check: ~8 kcal per km at moderate effort
                        double dist_cal = m1 * 8.0;
                        return Math.Round((base_cal + dist_cal) / 2.0, 1);
                    }

                case "Swimming":
                    {
                        // m1 = laps, m2 = time (min), m3 = avg heart rate (bpm)
                        // Each lap in a standard 25 m pool ≈ 14–15 kcal
                        double lapCal = m1 * 14.5;
                        // MET-based: freestyle MET ≈ 8.3
                        double met = 8.3;
                        double timeHrs = m2 / 60.0;
                        double met_cal = met * weight * timeHrs;
                        // Heart-rate bonus: HR > 140 adds extra burn
                        double hrBonus = m3 > 140 ? (m3 - 140) * 0.1 * m2 : 0;
                        return Math.Round((lapCal + met_cal) / 2.0 + hrBonus, 1);
                    }

                case "Pushups":
                    {
                        // m1 = reps, m2 = sets, m3 = time (min)
                        double repCal = m1 * m2 * 0.36;   // ~0.36 kcal per push-up
                        double timeCal = m3 * 3.0;          // 3 kcal/min (low-intensity)
                        return Math.Round((repCal + timeCal) / 2.0, 1);
                    }

                case "Jump Rope":
                    {
                        // m1 = jumps, m2 = time (min), m3 = avg heart rate (bpm)
                        double met = 12.3;
                        double timeHrs = m2 / 60.0;
                        double met_cal = met * weight * timeHrs;
                        // Per-jump estimate: ~0.1 kcal per jump
                        double jumpCal = m1 * 0.1;
                        double hrBonus = m3 > 150 ? (m3 - 150) * 0.05 * m2 : 0;
                        return Math.Round((met_cal + jumpCal) / 2.0 + hrBonus, 1);
                    }

                default: return 0;
            }
        }
    }
}