using System;
using System.Drawing;
using System.Windows.Forms;
using project.Models;
using project.Services;
using project.UI;

namespace project.Forms
{
    public class ActivityForm : Form
    {
        ComboBox cbActivity;
        TextBox tb1, tb2, tb3;
        Label lblError;

        public ActivityForm()
        {
            Text = "Add Activity";
            Size = new Size(420, 460);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Background;
            FormBorderStyle = FormBorderStyle.FixedDialog;

            BuildUI();
        }

        void BuildUI()
        {
            var card = new Panel
            {
                Left = 30,
                Top = 30,
                Width = 340,
                Height = 340,
                BackColor = Theme.Surface
            };
            Controls.Add(card);

            card.Controls.Add(Theme.StyledLabel("Select Activity", 20, 20, Theme.FontHeading, Theme.TextPrimary));

            cbActivity = new ComboBox
            {
                Left = 20,
                Top = 50,
                Width = 280,
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            cbActivity.Items.AddRange(new string[]
            {
                "Walking", "Running", "Cycling",
                "Swimming", "Pushups", "Jump Rope"
            });

            card.Controls.Add(cbActivity);

            tb1 = Theme.StyledTextBox(); tb1.Left = 20; tb1.Top = 100; tb1.Width = 280;
            tb2 = Theme.StyledTextBox(); tb2.Left = 20; tb2.Top = 140; tb2.Width = 280;
            tb3 = Theme.StyledTextBox(); tb3.Left = 20; tb3.Top = 180; tb3.Width = 280;

            card.Controls.Add(tb1);
            card.Controls.Add(tb2);
            card.Controls.Add(tb3);

            lblError = new Label
            {
                Left = 20,
                Top = 220,
                Width = 280,
                ForeColor = Theme.Danger
            };
            card.Controls.Add(lblError);

            var btn = Theme.StyledButton("Add Activity");
            btn.Left = 20; btn.Top = 250; btn.Width = 280;
            card.Controls.Add(btn);

            btn.Click += (s, e) =>
            {
                lblError.Text = "";

                if (cbActivity.SelectedItem == null)
                {
                    lblError.Text = "Select activity";
                    return;
                }

                if (!double.TryParse(tb1.Text, out double m1) ||
                    !double.TryParse(tb2.Text, out double m2) ||
                    !double.TryParse(tb3.Text, out double m3))
                {
                    lblError.Text = "Enter valid numbers";
                    return;
                }

                string name = cbActivity.SelectedItem.ToString();
                double calories = CalculateCalories(name, m1, m2, m3);

                var act = new ActivityEntry(name, "M1", m1, "M2", m2, "M3", m3, calories);
                UserStore.CurrentUser.AddActivity(act);
                UserStore.Save();

                this.Close();
            };
        }

        double CalculateCalories(string name, double m1, double m2, double m3)
        {
            switch (name)
            {
                case "Walking": return m2 * 50 + m3 * 2;
                case "Running": return m2 * 80 + m3 * 5;
                case "Cycling": return m2 * 60 + m3 * 4;
                case "Swimming": return m2 * 70 + m3 * 6;
                case "Pushups": return m1 * 0.5 + m3 * 2;
                case "Jump Rope": return m3 * 10 + m1 * 0.2;
                default: return 0;
            }
        }
    }
}