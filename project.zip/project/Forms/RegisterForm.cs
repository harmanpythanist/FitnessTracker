using System;
using System.Drawing;
using System.Windows.Forms;
using project.Services;
using project.Security;
using project.UI;

namespace project.Forms
{
    public class RegisterForm : Form
    {
        TextBox tbUsername, tbPassword;
        Label lblError, lblSuccess;

        public RegisterForm()
        {
            Text = "FitTrack — Register";
            Size = new Size(420, 460);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Background;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;

            BuildUI();
        }

        void BuildUI()
        {
            Controls.Add(new Label
            {
                Text = "Create Account",
                Left = 40,
                Top = 30,
                AutoSize = true,
                Font = Theme.FontTitle,
                ForeColor = Theme.TextPrimary
            });

            var card = new Panel
            {
                Left = 40,
                Top = 90,
                Width = 320,
                Height = 260,
                BackColor = Theme.Surface
            };
            Controls.Add(card);

            card.Controls.Add(Theme.StyledLabel("Username", 20, 20, Theme.FontSmall, Theme.TextSec));
            tbUsername = Theme.StyledTextBox();
            tbUsername.Left = 20; tbUsername.Top = 40; tbUsername.Width = 260;
            card.Controls.Add(tbUsername);

            card.Controls.Add(Theme.StyledLabel("Password", 20, 80, Theme.FontSmall, Theme.TextSec));
            tbPassword = Theme.StyledTextBox();
            tbPassword.Left = 20; tbPassword.Top = 100; tbPassword.Width = 260;
            tbPassword.UseSystemPasswordChar = true;
            card.Controls.Add(tbPassword);

            lblError = new Label
            {
                Left = 20,
                Top = 135,
                Width = 260,
                Height = 20,
                ForeColor = Theme.Danger,
                Font = Theme.FontSmall
            };
            card.Controls.Add(lblError);

            lblSuccess = new Label
            {
                Left = 20,
                Top = 160,
                Width = 260,
                Height = 20,
                ForeColor = Theme.Success,
                Font = Theme.FontSmall
            };
            card.Controls.Add(lblSuccess);

            var btnRegister = Theme.StyledButton("REGISTER");
            btnRegister.Left = 20;
            btnRegister.Top = 190;
            btnRegister.Width = 260;
            card.Controls.Add(btnRegister);

            btnRegister.Click += (s, e) =>
            {
                lblError.Text = "";
                lblSuccess.Text = "";

                string username = tbUsername.Text.Trim();
                string password = tbPassword.Text;

                if (!SecurityHelper.ValidateUsername(username, out string uErr))
                {
                    lblError.Text = uErr;
                    return;
                }

                if (!SecurityHelper.ValidatePassword(password, out string pErr))
                {
                    lblError.Text = pErr;
                    return;
                }

                string hash = SecurityHelper.HashPassword(password);

                if (!UserStore.Register(username, hash, out string error))
                {
                    lblError.Text = error;
                    return;
                }

                lblSuccess.Text = "✔ Account created successfully!";

                tbUsername.Text = "";
                tbPassword.Text = "";
            };
        }
    }
}