using System;
using System.Drawing;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using project.Services;
using project.Security;
using project.UI;

namespace project.Forms
{
    public class RegisterForm : Form
    {
        TextBox tbName, tbPhone, tbUsername, tbPassword;
        Label lblError, lblSuccess;

        public RegisterForm()
        {
            Text = "FitTrack — Register";
            Size = new Size(420, 560);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Background;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;

            BuildUI();
        }

        void BuildUI()
        {
            Controls.Add(new Label
            {
                Text = "Create Account",
                Left = 40,
                Top = 30,
                AutoSize = true,
                Font = Theme.FontTitle,
                ForeColor = Theme.TextPrimary
            });

            var card = new Panel
            {
                Left = 40,
                Top = 90,
                Width = 320,
                Height = 380,
                BackColor = Theme.Surface
            };
            Controls.Add(card);

            // Full Name
            card.Controls.Add(Theme.StyledLabel("Full Name", 20, 20, Theme.FontSmall, Theme.TextSec));
            tbName = Theme.StyledTextBox();
            tbName.Left = 20; tbName.Top = 40; tbName.Width = 260;
            card.Controls.Add(tbName);

            // Phone Number
            card.Controls.Add(Theme.StyledLabel("Phone Number", 20, 80, Theme.FontSmall, Theme.TextSec));
            tbPhone = Theme.StyledTextBox();
            tbPhone.Left = 20; tbPhone.Top = 100; tbPhone.Width = 260;
            card.Controls.Add(tbPhone);

            // Username
            card.Controls.Add(Theme.StyledLabel("Username", 20, 140, Theme.FontSmall, Theme.TextSec));
            tbUsername = Theme.StyledTextBox();
            tbUsername.Left = 20; tbUsername.Top = 160; tbUsername.Width = 260;
            card.Controls.Add(tbUsername);

            // Password
            card.Controls.Add(Theme.StyledLabel("Password", 20, 200, Theme.FontSmall, Theme.TextSec));
            tbPassword = Theme.StyledTextBox();
            tbPassword.Left = 20; tbPassword.Top = 220; tbPassword.Width = 260;
            tbPassword.UseSystemPasswordChar = true;
            card.Controls.Add(tbPassword);

            // Error label
            lblError = new Label
            {
                Left = 20,
                Top = 255,
                Width = 260,
                Height = 20,
                ForeColor = Theme.Danger,
                Font = Theme.FontSmall
            };
            card.Controls.Add(lblError);

            // Success label
            lblSuccess = new Label
            {
                Left = 20,
                Top = 278,
                Width = 260,
                Height = 20,
                ForeColor = Theme.Success,
                Font = Theme.FontSmall
            };
            card.Controls.Add(lblSuccess);

            // Register button
            var btnRegister = Theme.StyledButton("REGISTER");
            btnRegister.Left = 20;
            btnRegister.Top = 310;
            btnRegister.Width = 260;
            card.Controls.Add(btnRegister);

            btnRegister.Click += (s, e) =>
            {
                lblError.Text = "";
                lblSuccess.Text = "";

                string name = tbName.Text.Trim();
                string phone = tbPhone.Text.Trim();
                string username = tbUsername.Text.Trim();
                string password = tbPassword.Text;

                if (string.IsNullOrEmpty(name))
                {
                    lblError.Text = "Full name is required.";
                    return;
                }

                if (!Regex.IsMatch(phone, @"^\+?[0-9\s\-]{7,15}$"))
                {
                    lblError.Text = "Enter a valid phone number.";
                    return;
                }

                if (!SecurityHelper.ValidateUsername(username, out string uErr))
                {
                    lblError.Text = uErr;
                    return;
                }

                if (!SecurityHelper.ValidatePassword(password, out string pErr))
                {
                    lblError.Text = pErr;
                    return;
                }

                string hash = SecurityHelper.HashPassword(password);

                if (!UserStore.Register(username, hash, name, phone, out string error))
                {
                    lblError.Text = error;
                    return;
                }

                lblSuccess.Text = "✔ Account created successfully!";
                tbName.Text = tbPhone.Text = tbUsername.Text = tbPassword.Text = "";
            };
        }
    }
}