using System;
using System.Drawing;
using System.Windows.Forms;
using project.Services;
using project.UI;

namespace project.Forms
{
    public class GoalForm : Form
    {
        TextBox tbGoal;
        Label lblError, lblSaved;

        public GoalForm()
        {
            Text = "Set Goal";
            Size = new Size(420, 360);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Background;
            FormBorderStyle = FormBorderStyle.FixedDialog;

            BuildUI();
        }

        void BuildUI()
        {
            var card = new Panel
            {
                Left = 30,
                Top = 40,
                Width = 340,
                Height = 240,
                BackColor = Theme.Surface
            };
            Controls.Add(card);

            card.Controls.Add(Theme.StyledLabel("Daily Calorie Goal (kcal)", 20, 20, Theme.FontHeading, Theme.TextPrimary));

            tbGoal = Theme.StyledTextBox();
            tbGoal.Left = 20; tbGoal.Top = 60; tbGoal.Width = 280;
            card.Controls.Add(tbGoal);

            if (UserStore.CurrentUser.CalorieGoal > 0)
                tbGoal.Text = UserStore.CurrentUser.CalorieGoal.ToString();

            lblError = new Label
            {
                Left = 20,
                Top = 100,
                Width = 280,
                ForeColor = Theme.Danger
            };
            card.Controls.Add(lblError);

            lblSaved = new Label
            {
                Left = 20,
                Top = 100,
                Width = 280,
                ForeColor = Theme.Success
            };
            card.Controls.Add(lblSaved);

            var btn = Theme.StyledButton("Save");
            btn.Left = 20; btn.Top = 140; btn.Width = 280;
            card.Controls.Add(btn);

            btn.Click += (s, e) =>
            {
                lblError.Text = "";
                lblSaved.Text = "";

                if (!double.TryParse(tbGoal.Text, out double g) || g <= 0)
                {
                    lblError.Text = "Enter valid number";
                    return;
                }

                UserStore.CurrentUser.CalorieGoal = g;
                UserStore.Save();

                lblSaved.Text = "Goal saved";
                this.Close();
            };
        }
    }
}