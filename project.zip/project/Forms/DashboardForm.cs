using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using project.Services;
using project.UI;

namespace project.Forms
{
    public class DashboardForm : Form
    {
        Panel pnlMain;
        Label lblWelcome;

        public DashboardForm()
        {
            Text = "FitTrack — Dashboard";
            Size = new Size(1024, 720);
            StartPosition = FormStartPosition.CenterScreen;
            BackColor = Theme.Background;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;

            BuildUI();
            ShowDashboard();
        }

        void BuildUI()
        {
            lblWelcome = new Label
            {
                Left = 20,
                Top = 15,
                AutoSize = true,
                Font = Theme.FontHeading,
                ForeColor = Theme.TextPrimary
            };
            Controls.Add(lblWelcome);

            var btnGoal = Theme.StyledButton("Set Goal");
            btnGoal.Left = 600; btnGoal.Top = 10; btnGoal.Width = 100;
            Controls.Add(btnGoal);

            btnGoal.Click += (s, e) =>
            {
                var f = new GoalForm();
                f.ShowDialog();
                ShowDashboard();
            };

            var btnActivity = Theme.StyledButton("Add Activity");
            btnActivity.Left = 710; btnActivity.Top = 10; btnActivity.Width = 120;
            Controls.Add(btnActivity);

            btnActivity.Click += (s, e) =>
            {
                var f = new ActivityForm();
                f.ShowDialog();
                ShowDashboard();
            };

            pnlMain = new Panel
            {
                Left = 0,
                Top = 50,
                Width = 860,
                Height = 560,
                BackColor = Theme.Background
            };
            Controls.Add(pnlMain);
        }

        void AddStatCard(int x, int y, string title, string value, Color accent)
        {
            var card = new Panel
            {
                Left = x,
                Top = y,
                Width = 230,
                Height = 120, // increased height
                BackColor = Theme.Card
            };

            // Accent bar
            card.Controls.Add(new Panel
            {
                Left = 0,
                Top = 0,
                Width = 230,
                Height = 6, // slightly thicker
                BackColor = accent
            });

            // Title
            card.Controls.Add(new Label
            {
                Text = title,
                Left = 16,
                Top = 10,   // give some padding from top
                Width = 200,
                Height = 25,
                AutoSize = false,
                ForeColor = Theme.TextSec,
                Font = new Font("Segoe UI", 11f, FontStyle.Regular),
                BackColor = Color.Transparent
            });

            // Value
            card.Controls.Add(new Label
            {
                Text = value,
                Left = 16,
                Top = 45,  // space from title
                Width = 200,
                Height = 50,
                AutoSize = false,
                ForeColor = accent,
                Font = new Font("Segoe UI", 20f, FontStyle.Bold),
                BackColor = Color.Transparent,
                TextAlign = ContentAlignment.MiddleLeft
            });

            pnlMain.Controls.Add(card);
        }

        public void ShowDashboard()
        {
            var u = UserStore.CurrentUser;
            if (u == null)
            {
                MessageBox.Show("User is NULL!");
                return;
            }

    
            lblWelcome.Text = $"Hello, {u.Username}";
            pnlMain.Controls.Clear();

            pnlMain.Controls.Add(new Label
            {
                Text = "Dashboard Overview",
                ForeColor = Theme.TextPrimary,
                Font = Theme.FontTitle,
                Left = 30,
                Top = 20,
                AutoSize = true
            });

            pnlMain.Controls.Add(Theme.StyledLabel(
                $"📅 {DateTime.Today:dddd, dd MMMM yyyy}",
                30, 60, Theme.FontBody, Theme.TextSec));

            double todayTotal = u.GetTodayCalories();
            int todayCount = u.GetTodayActivityCount();
            double goal = u.CalorieGoal;
            double remaining = Math.Max(0, goal - todayTotal);
            bool achieved = u.IsGoalAchieved();

            AddStatCard(30, 100, "Today Burned", $"{todayTotal:F0} kcal", Theme.Warning);
            AddStatCard(290, 100, "Goal", goal > 0 ? $"{goal:F0} kcal" : "Not Set", Theme.Accent);
            AddStatCard(550, 100, "Activities", todayCount.ToString(), Theme.Purple);

            int bannerBottom = 200;

            if (goal > 0)
            {
                var banner = new Panel
                {
                    Left = 30,
                    Top = 240,
                    Width = 760,
                    Height = 70,
                    BackColor = achieved
                        ? Color.FromArgb(30, 50, 220, 140)
                        : Color.FromArgb(30, 255, 80, 100),
                    Padding = new Padding(12)
                };

                banner.Controls.Add(new Label
                {
                    Text = achieved
                        ? "🎉  Goal Achieved! Amazing work!"
                        : $"⚡  Keep going! Only {remaining:F0} kcal left!",
                    ForeColor = achieved ? Theme.Success : Theme.Danger,
                    Font = Theme.FontHeading,
                    Dock = DockStyle.Fill,
                    TextAlign = ContentAlignment.MiddleLeft,
                    AutoSize = false
                });

                pnlMain.Controls.Add(banner);
                bannerBottom = banner.Bottom;
            }

            pnlMain.Controls.Add(new Panel
            {
                Left = 30,
                Top = bannerBottom + 10,
                Width = 760,
                Height = 1,
                BackColor = Color.FromArgb(40, 255, 255, 255)
            });

            int listTop = bannerBottom + 40;

            pnlMain.Controls.Add(Theme.StyledLabel(
                "Today's Activities",
                30,
                listTop - 20,
                Theme.FontHeading,
                Theme.TextSec));

            int listTopp = bannerBottom + 50; // leave more space below banner

            var lst = new ListBox
            {
                Left = 30,
                Top = listTopp,
                Width = pnlMain.Width - 50, // dynamic width
                Height = pnlMain.Height - listTopp - 30, // dynamic height
                BackColor = Theme.Card,
                ForeColor = Theme.TextPrimary,
                Font = Theme.FontBody,
                BorderStyle = BorderStyle.None,
                ItemHeight = 24
            };

            var todayActs = u.Activities
                .Where(a => a.Date.Date == DateTime.Today)
                .ToList();

            if (todayActs.Count == 0)
                lst.Items.Add("  No activities recorded today.");
            else
                foreach (var a in todayActs)
                    lst.Items.Add($"  {a}");

            pnlMain.Controls.Add(lst);
        }
    }
}