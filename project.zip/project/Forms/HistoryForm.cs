using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using project.Services;
using project.UI;

namespace project.Forms
{
    public class HistoryForm : Form
    {
        public HistoryForm()
        {
            Text = "Activity History";
            Size = new Size(700, 520);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Background;

            BuildUI();
        }

        void BuildUI()
        {
            Controls.Add(new Label
            {
                Text = "All Activities",
                Left = 30,
                Top = 20,
                AutoSize = true,
                Font = Theme.FontTitle,
                ForeColor = Theme.TextPrimary
            });

            var list = new ListBox
            {
                Left = 30,
                Top = 70,
                Width = 620,
                Height = 360,
                BackColor = Theme.Card,
                ForeColor = Theme.TextPrimary,
                Font = Theme.FontBody,
                BorderStyle = BorderStyle.None,
                ItemHeight = 24
            };

            var activities = UserStore.CurrentUser.Activities
                .OrderByDescending(a => a.Date)
                .ToList();

            if (activities.Count == 0)
            {
                list.Items.Add("  No activity history available.");
            }
            else
            {
                foreach (var a in activities)
                {
                    list.Items.Add($"  {a.Date:dd MMM yyyy}  |  {a.ToDetailedString()}");
                }
            }

            Controls.Add(list);

            var btnClose = Theme.StyledButton("Close");
            btnClose.Left = 30;
            btnClose.Top = 450;
            btnClose.Width = 620;
            Controls.Add(btnClose);

            btnClose.Click += (s, e) => this.Close();
        }
    }
}