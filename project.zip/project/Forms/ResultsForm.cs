using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using project.Services;
using project.UI;

namespace project.Forms
{
    public class ResultsForm : Form
    {
        public ResultsForm()
        {
            Text = "Results";
            Size = new Size(600, 500);
            StartPosition = FormStartPosition.CenterParent;
            BackColor = Theme.Background;

            BuildUI();
        }

        void BuildUI()
        {
            var u = UserStore.CurrentUser;

            double total = u.GetTodayCalories();
            double goal = u.CalorieGoal;

            Controls.Add(new Label
            {
                Text = "Today's Results",
                Left = 30,
                Top = 20,
                AutoSize = true,
                Font = Theme.FontTitle,
                ForeColor = Theme.TextPrimary
            });

            Controls.Add(Theme.StyledLabel($"Calories Burned: {total:F0}", 30, 70, Theme.FontHeading, Theme.Warning));
            Controls.Add(Theme.StyledLabel($"Goal: {goal:F0}", 30, 100, Theme.FontHeading, Theme.Accent));

            Controls.Add(Theme.StyledLabel(
                total >= goal ? "🎉 Goal Achieved!" : "⚡ Keep going!",
                30, 140, Theme.FontHeading,
                total >= goal ? Theme.Success : Theme.Danger));

            var list = new ListBox
            {
                Left = 30,
                Top = 180,
                Width = 520,
                Height = 220,
                BackColor = Theme.Card,
                ForeColor = Theme.TextPrimary,
                Font = Theme.FontBody
            };

            var acts = u.Activities.Where(a => a.Date.Date == DateTime.Today);

            foreach (var a in acts)
                list.Items.Add(a.ToDetailedString());

            Controls.Add(list);
        }
    }
}