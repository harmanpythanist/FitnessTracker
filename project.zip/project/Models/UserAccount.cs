using System.Collections.Generic;

namespace project.Models
{
    /// <summary>
    /// Represents a user in the fitness tracking system.
    /// Stores authentication info, goal, and activity history.
    /// </summary>
    public class UserAccount
    {
        // ── Authentication ──
        public string Username { get; set; }
        public string PasswordHash { get; set; }

        // ── Profile ──
        public string Name { get; set; }
        public string Phone { get; set; }

        // ── Security ──
        public int FailedAttempts { get; set; }
        public bool IsLocked { get; set; }

        // ── Goal ──
        public double CalorieGoal { get; set; }
        public DateTime CurrentGoalStartedAt { get; set; }

        // ── Activity History ──
        public List<ActivityEntry> Activities { get; set; }

        /// <summary>
        /// Default constructor (required for JSON serialization)
        /// </summary>
        // Default constructor
        public UserAccount()
        {
            Name = "";
            Phone = "";
            Activities = new List<ActivityEntry>();
            FailedAttempts = 0;
            IsLocked = false;
            CalorieGoal = 0;
            CurrentGoalStartedAt = DateTime.MinValue;
        }

        // Registration constructor
        public UserAccount(string username, string passwordHash)
        {
            Username = username;
            PasswordHash = passwordHash;
            Name = "";
            Phone = "";
            Activities = new List<ActivityEntry>();
            FailedAttempts = 0;
            IsLocked = false;
            CalorieGoal = 0;
            CurrentGoalStartedAt = DateTime.MinValue;
        }

        // ── Helper Methods (Clean & Useful) ──

        /// <summary>
        /// Adds a new activity to the user's history
        /// </summary>
        public void AddActivity(ActivityEntry activity)
        {
            Activities.Add(activity);
        }

        /// <summary>
        /// Calculates total calories burned (all time)
        /// </summary>
        public double GetTotalCalories()
        {
            double total = 0;
            foreach (var a in Activities)
                total += a.CaloriesBurned;

            return total;
        }

        /// <summary>
        /// Calculates today's calories
        /// </summary>
        public double GetTodayCalories()
        {
            double total = 0;
            var today = System.DateTime.Today;

            foreach (var a in Activities)
            {
                if (a.Date.Date == today && a.Date >= CurrentGoalStartedAt)
                    total += a.CaloriesBurned;
            }

            return total;
        }

        /// <summary>
        /// Returns number of activities today
        /// </summary>
        public int GetTodayActivityCount()
        {
            int count = 0;
            var today = System.DateTime.Today;

            foreach (var a in Activities)
            {
                if (a.Date.Date == today && a.Date >= CurrentGoalStartedAt)
                    count++;
            }

            return count;
        }

        /// <summary>
        /// Checks if daily goal is achieved
        /// </summary>
        public bool IsGoalAchieved()
        {
            if (CalorieGoal <= 0)
                return false;

            return GetTodayCalories() >= CalorieGoal;
        }
    }
}