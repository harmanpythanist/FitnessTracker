using System;

namespace project.Models
{
    /// <summary>
    /// Represents a single fitness activity with 3 metrics and calculated calories.
    /// </summary>
    public class ActivityEntry
    {
        // ── Activity Info ──
        public string ActivityName { get; set; }

        // ── Metric Labels (e.g., Steps, Distance, Time) ──
        public string Metric1Label { get; set; }
        public string Metric2Label { get; set; }
        public string Metric3Label { get; set; }

        // ── Metric Values ──
        public double Metric1 { get; set; }
        public double Metric2 { get; set; }
        public double Metric3 { get; set; }

        // ── Result ──
        public double CaloriesBurned { get; set; }

        // ── Date ──
        public DateTime Date { get; set; }

        /// <summary>
        /// Default constructor (required for JSON serialization)
        /// </summary>
        public ActivityEntry()
        {
            Date = DateTime.Now;
        }

        /// <summary>
        /// Full constructor
        /// </summary>
        public ActivityEntry(
            string name,
            string m1Label, double m1,
            string m2Label, double m2,
            string m3Label, double m3,
            double calories)
        {
            ActivityName = name;

            Metric1Label = m1Label;
            Metric1 = m1;

            Metric2Label = m2Label;
            Metric2 = m2;

            Metric3Label = m3Label;
            Metric3 = m3;

            CaloriesBurned = calories;
            Date = DateTime.Now;
        }

        /// <summary>
        /// Short display (for dashboard/list)
        /// </summary>
        public override string ToString()
        {
            return $"{ActivityName.PadRight(18)} {CaloriesBurned:F1} kcal";
        }

        /// <summary>
        /// Detailed display (for results/history page)
        /// </summary>
        public string ToDetailedString()
        {
            return $"{ActivityName} | " +
                   $"{Metric1Label}: {Metric1}, " +
                   $"{Metric2Label}: {Metric2}, " +
                   $"{Metric3Label}: {Metric3} → " +
                   $"{CaloriesBurned:F1} kcal";
        }
    }
}