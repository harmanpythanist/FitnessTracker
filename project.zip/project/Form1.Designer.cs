﻿using System.Windows.Forms;

namespace project
{
    partial class Form1  // <-- partial, same name, same namespace
    {
        private void InitializeComponent()
        {
            // Set basic form properties
            this.Text = "FitTrack";
            this.Width = 800;
            this.Height = 600;

            // Example controls
            Button btn = new Button();
            btn.Text = "Click Me!";
            btn.Left = 50;
            btn.Top = 50;
            this.Controls.Add(btn);

            Label lbl = new Label();
            lbl.Text = "Welcome to FitTrack!";
            lbl.Left = 50;
            lbl.Top = 100;
            lbl.AutoSize = true;
            this.Controls.Add(lbl);
        }
    }
}