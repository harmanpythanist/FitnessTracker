using System;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace project.Security
{
    /// <summary>
    /// Handles password hashing and input validation.
    /// </summary>
    public static class SecurityHelper
    {
        // ── PASSWORD HASHING (SHA-256) ──
        public static string HashPassword(string password)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = Encoding.UTF8.GetBytes(password);
                byte[] hash = sha.ComputeHash(bytes);

                // Convert to readable hex string
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hash)
                    sb.Append(b.ToString("x2"));

                return sb.ToString();
            }
        }

        // ── USERNAME VALIDATION ──
        public static bool ValidateUsername(string username, out string error)
        {
            error = "";

            if (string.IsNullOrWhiteSpace(username))
            {
                error = "Username cannot be empty.";
                return false;
            }

            // Only letters and numbers allowed
            if (!Regex.IsMatch(username, @"^[a-zA-Z0-9]+$"))
            {
                error = "Username must contain only letters and numbers.";
                return false;
            }

            return true;
        }

        // ── PASSWORD VALIDATION ──
        public static bool ValidatePassword(string password, out string error)
        {
            error = "";

            if (string.IsNullOrWhiteSpace(password))
            {
                error = "Password cannot be empty.";
                return false;
            }

            if (password.Length < 12)
            {
                error = "Password must be at least 12 characters long.";
                return false;
            }

            if (!Regex.IsMatch(password, @"[A-Z]"))
            {
                error = "Password must contain at least one uppercase letter.";
                return false;
            }

            if (!Regex.IsMatch(password, @"[a-z]"))
            {
                error = "Password must contain at least one lowercase letter.";
                return false;
            }

            return true;
        }
    }
}